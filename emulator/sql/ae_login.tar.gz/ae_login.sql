/*
Navicat MySQL Data Transfer

Source Server         : StarLoco
Source Server Version : 50612
Source Host           : localhost:3306
Source Database       : ae_login

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-09-13 23:23:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `accounts`
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `guid` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(30) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `lastIP` varchar(25) NOT NULL,
  `lastConnectionDate` varchar(100) NOT NULL,
  `migration` tinyint(1) NOT NULL DEFAULT '0',
  `question` varchar(100) NOT NULL DEFAULT 'supprimer ?',
  `reponse` varchar(100) NOT NULL DEFAULT 'oui',
  `pseudo` varchar(30) NOT NULL,
  `banned` tinyint(3) NOT NULL DEFAULT '0',
  `banned_time` bigint(20) NOT NULL DEFAULT '0',
  `reload_needed` tinyint(1) NOT NULL DEFAULT '1',
  `bankKamas` int(11) NOT NULL DEFAULT '0',
  `bank` text NOT NULL,
  `friends` text NOT NULL,
  `enemy` text NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `logged` int(11) NOT NULL DEFAULT '0',
  `cadeau` int(11) NOT NULL,
  `subscribe` bigint(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=149988 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of accounts
-- ----------------------------
INSERT INTO `accounts` VALUES ('1', 'locos975', '123', '6', '', '92.129.119.161', '2014~09~02~19~30', '1', 'supprimer ?', 'oui', 'Locos5', '0', '0', '0', '0', '', '', '', '0', '0', '0', '0');
INSERT INTO `accounts` VALUES ('2', 'locos974', '123', '6', '', '', '2014~06~22~12~14', '0', 'supprimer ?', 'oui', 'Locos4', '0', '0', '0', '0', '', '1', '', '0', '0', '0', '0');
INSERT INTO `accounts` VALUES ('3', 'locos976', '123', '6', '', '127.0.0.1', '2014~05~03~13~34', '0', 'supprimer ?', 'oui', 'LocosII', '0', '0', '0', '0', '', '', '', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `banip`
-- ----------------------------
DROP TABLE IF EXISTS `banip`;
CREATE TABLE `banip` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of banip
-- ----------------------------

-- ----------------------------
-- Table structure for `players`
-- ----------------------------
DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) DEFAULT NULL,
  `name` varchar(30) NOT NULL,
  `sexe` tinyint(4) NOT NULL,
  `class` smallint(6) NOT NULL,
  `color1` int(11) NOT NULL,
  `color2` int(11) NOT NULL,
  `color3` int(11) NOT NULL,
  `kamas` bigint(255) NOT NULL,
  `spellboost` int(11) NOT NULL,
  `capital` int(11) NOT NULL,
  `energy` int(11) NOT NULL DEFAULT '10000',
  `level` int(11) NOT NULL,
  `xp` bigint(32) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL,
  `gfx` int(11) NOT NULL,
  `alignement` int(11) NOT NULL DEFAULT '0',
  `honor` int(11) NOT NULL DEFAULT '0',
  `deshonor` int(11) NOT NULL DEFAULT '0',
  `alvl` int(11) NOT NULL DEFAULT '0' COMMENT 'Niveau alignement',
  `vitalite` int(11) NOT NULL DEFAULT '0',
  `force` int(11) NOT NULL DEFAULT '0',
  `sagesse` int(11) NOT NULL DEFAULT '0',
  `intelligence` int(11) NOT NULL DEFAULT '0',
  `chance` int(11) NOT NULL DEFAULT '0',
  `agilite` int(11) NOT NULL DEFAULT '0',
  `seeSpell` tinyint(4) NOT NULL DEFAULT '0',
  `seeFriend` tinyint(4) NOT NULL DEFAULT '1',
  `seeAlign` tinyint(4) NOT NULL DEFAULT '0',
  `seeSeller` tinyint(4) NOT NULL DEFAULT '0',
  `canaux` varchar(15) NOT NULL DEFAULT '*#%!pi$:?',
  `map` int(11) NOT NULL DEFAULT '8479',
  `cell` int(11) NOT NULL,
  `pdvper` int(11) NOT NULL DEFAULT '100',
  `spells` text NOT NULL,
  `objets` text NOT NULL,
  `storeObjets` text NOT NULL,
  `savepos` varchar(20) NOT NULL DEFAULT '10298,314',
  `zaaps` varchar(250) NOT NULL DEFAULT '',
  `jobs` varchar(300) NOT NULL DEFAULT '',
  `mountxpgive` int(11) NOT NULL DEFAULT '0',
  `mount` int(11) NOT NULL DEFAULT '-1',
  `title` int(11) NOT NULL DEFAULT '0',
  `wife` int(1) NOT NULL DEFAULT '0',
  `emotes` varchar(255) DEFAULT '1',
  `server` int(5) DEFAULT NULL,
  `logged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`wife`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of players
-- ----------------------------
INSERT INTO `players` VALUES ('1', '1', 'zjdav', '0', '6', '-1', '-1', '-1', '0', '0', '0', '10000', '1', '0', '100', '60', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '*#%!pi$:?', '10305', '349', '100', '102;1;b,103;1;c,105;1;d', '', '', '10298,314', '', '', '0', '-1', '0', '0', '1', '1', '0');
INSERT INTO `players` VALUES ('2', '1', 'crojc', '0', '2', '-1', '-1', '-1', '0', '0', '0', '10000', '1', '0', '100', '20', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '*#%!pi$:?', '10284', '368', '100', '21;1;c,23;1;d,34;1;b', '2333|2334|', '', '10298,314', '', '', '0', '-1', '0', '0', '1', '1', '0');
INSERT INTO `players` VALUES ('3', '1', 'LocosI', '0', '3', '-1', '-1', '-1', '8', '11', '5', '10000', '2', '600', '100', '30', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '*#%!pi$:?', '10298', '314', '100', '41;1;d,43;1;c,51;1;b,415;5;e', '2335|2336|', '', '10298,314', '', '', '0', '-1', '0', '0', '1', '1', '0');
INSERT INTO `players` VALUES ('4', '1', 'LocosXI', '0', '7', '-1', '-1', '-1', '0', '0', '0', '10000', '1', '0', '100', '70', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '*#%!pi$:?', '10283', '299', '100', '121;1;d,125;1;b,128;1;c', '', '', '10298,314', '', '', '0', '-1', '0', '0', '1', '13', '0');

-- ----------------------------
-- Table structure for `servers`
-- ----------------------------
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL DEFAULT '0',
  `key` text,
  `population` int(11) DEFAULT '0',
  `isSubscriberServer` int(11) DEFAULT '1',
  `uptime` bigint(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of servers
-- ----------------------------
INSERT INTO `servers` VALUES ('1', 'jiva', '0', '0', '1409678558396');
INSERT INTO `servers` VALUES ('2', 'rushu', '0', '1', '0');
INSERT INTO `servers` VALUES ('3', 'djaul', '0', '1', '0');
INSERT INTO `servers` VALUES ('4', 'raval', '0', '1', '0');
INSERT INTO `servers` VALUES ('5', 'hecate', '0', '1', '0');
INSERT INTO `servers` VALUES ('6', 'sumens', '0', '1', '0');
INSERT INTO `servers` VALUES ('7', 'menalt', '0', '1', '0');
INSERT INTO `servers` VALUES ('8', 'rosal', '0', '1', '0');
INSERT INTO `servers` VALUES ('9', 'maimane', '0', '1', '0');
INSERT INTO `servers` VALUES ('10', 'silvosse', '0', '1', '0');
INSERT INTO `servers` VALUES ('11', 'brumaire', '0', '1', '0');
INSERT INTO `servers` VALUES ('12', 'pouchecot', '0', '1', '0');
INSERT INTO `servers` VALUES ('13', 'silouate', '0', '0', '1409678533809');
INSERT INTO `servers` VALUES ('14', 'domen', '0', '1', '0');
INSERT INTO `servers` VALUES ('15', 'amayiro', '0', '1', '0');
INSERT INTO `servers` VALUES ('16', 'rykkla_errel', '0', '1', '0');
INSERT INTO `servers` VALUES ('17', 'hyrkul', '0', '1', '0');
INSERT INTO `servers` VALUES ('18', 'helsephine', '0', '1', '0');
INSERT INTO `servers` VALUES ('19', 'allister', '0', '1', '0');
INSERT INTO `servers` VALUES ('20', 'otomai', '0', '1', '0');
INSERT INTO `servers` VALUES ('21', 'lily', '0', '1', '0');
INSERT INTO `servers` VALUES ('22', 'oto_mustan', '0', '1', '0');
INSERT INTO `servers` VALUES ('23', 'hel_munster', '0', '1', '0');
INSERT INTO `servers` VALUES ('24', 'danathor', '0', '1', '0');
INSERT INTO `servers` VALUES ('25', 'kuri', '0', '1', '0');
INSERT INTO `servers` VALUES ('26', 'mylaise', '0', '1', '0');
INSERT INTO `servers` VALUES ('27', 'goultard', '0', '1', '0');
INSERT INTO `servers` VALUES ('28', 'ulette', '0', '1', '0');
INSERT INTO `servers` VALUES ('29', 'vil_smisse', '0', '1', '0');
INSERT INTO `servers` VALUES ('30', 'many', '0', '1', '0');
INSERT INTO `servers` VALUES ('31', 'solar', '0', '1', '0');
INSERT INTO `servers` VALUES ('32', 'crocoburio', '0', '1', '0');
INSERT INTO `servers` VALUES ('33', 'li_crounch', '0', '1', '0');
INSERT INTO `servers` VALUES ('35', 'farle', '0', '1', '0');
INSERT INTO `servers` VALUES ('36', 'agride', '0', '1', '0');
INSERT INTO `servers` VALUES ('37', 'bowisse', '0', '1', '0');
INSERT INTO `servers` VALUES ('38', 'ogivol', '0', '1', '0');
INSERT INTO `servers` VALUES ('39', 'lethaline', '0', '1', '0');
INSERT INTO `servers` VALUES ('40', 'aemyne', '0', '1', '0');
INSERT INTO `servers` VALUES ('41', 'zatoishwan', '0', '1', '0');
INSERT INTO `servers` VALUES ('99', 'tournois', '0', '1', '0');
INSERT INTO `servers` VALUES ('900', 'test', '0', '1', '0');
INSERT INTO `servers` VALUES ('1001', 'shika', '0', '1', '0');
INSERT INTO `servers` VALUES ('3001', 'nehra', '0', '1', '0');
INSERT INTO `servers` VALUES ('3002', 'katar', '0', '1', '0');
INSERT INTO `servers` VALUES ('4001', 'alma', '0', '1', '0');
INSERT INTO `servers` VALUES ('4002', 'aguabrial', '0', '1', '0');
INSERT INTO `servers` VALUES ('4003', 'buhorado', '0', '1', '0');
INSERT INTO `servers` VALUES ('4004', 'tenebres', '0', '1', '0');
INSERT INTO `servers` VALUES ('4005', 'bolgrot', '0', '1', '0');
INSERT INTO `servers` VALUES ('4006', 'nomekop', '0', '1', '0');
INSERT INTO `servers` VALUES ('4007', 'edasse', '0', '1', '0');
INSERT INTO `servers` VALUES ('4008', 'eratz', '0', '1', '0');
INSERT INTO `servers` VALUES ('6001', 'spiritia', '0', '1', '0');
INSERT INTO `servers` VALUES ('6002', 'helioboros', '0', '1', '0');
INSERT INTO `servers` VALUES ('7001', 'darkvlad', '0', '1', '0');
INSERT INTO `servers` VALUES ('9001', 'ereziah', '0', '1', '0');
